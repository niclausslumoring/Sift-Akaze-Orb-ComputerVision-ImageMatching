import numpy as np
import cv2 as cv
import matplotlib.pyplot as plt

#Ambil Gambar
img_obj = cv.imread("box.png")
img_scn = cv.imread("box_in_scene.png")

#SIFT, AKAZE, ORB
sift = cv.SIFT_create()
akaze = cv.AKAZE_create()
orb = cv.ORB_create()

#Object ngedeteksi keypoint & descriptor2nya
#parameter 1 = source image
#parameter 2 = masking -> NONE
sift_kp_obj, sift_ds_obj = sift.detectAndCompute(img_obj, None)
sift_kp_scn, sift_ds_scn = sift.detectAndCompute(img_scn, None)

#Nunjukin koordinatnya 
#print(sift_kp_obj[0].pt)  

akaze_kp_obj, akaze_ds_obj = akaze.detectAndCompute(img_obj, None)
akaze_kp_scn, akaze_ds_scn = akaze.detectAndCompute(img_scn, None)

orb_kp_obj, orb_ds_obj = orb.detectAndCompute(img_obj, None)
orb_kp_scn, orb_ds_scn = orb.detectAndCompute(img_scn, None)

#Butuh nearest neighbor
#library tapi harus ubah dulu jadi float
sift_ds_obj = np.float32(sift_ds_obj)
sift_ds_scn = np.float32(sift_ds_scn)

akaze_ds_obj = np.float32(akaze_ds_obj)
akaze_ds_scn = np.float32(akaze_ds_scn)

#bruteforce buat bandingin obj & scene (AKAZE & SIFT)
#algoritm = 1, check = 50, kalo kebanyakan makan time + resource
flann = cv.FlannBasedMatcher(dict(algorithm = 1), dict(checks = 50))

#ORB
#Misal ada 1 titik yang udah ditraverse, titik 2 blom traverse bakal tetep dikalkulasiin
bf_matcher = cv.BFMatcher(cv.NORM_HAMMING, crossCheck = True)

#object di scene matcher
#cocokin descriptor yang ada di objet sama yang ada di scene
#kalo sama(best descriptor ada di target)
sift_match = flann.knnMatch(sift_ds_obj, sift_ds_scn, 2)
akaze_match = flann.knnMatch(akaze_ds_obj, akaze_ds_scn, 2)

orb_match = bf_matcher.match(orb_ds_obj, orb_ds_scn)
#sorted
orb_match = sorted(orb_match, key = lambda x : x.distance)

#knnmatch bisa aja ada yang bener2 sesuai, bisa juga ada yang salah

#bikin template kosong buat masking
sift_matchesmask = [[0,0] for i in range(0, len(sift_match))]
akaze_matchesmask = [[0,0] for i in range(0, len(akaze_match))]

#function
def createMask(mask, match):
    for i, (fm,sm) in enumerate(match):
        if(fm.distance < 0.7 * sm.distance):
            mask[i] = [1,0]
    return mask       

sift_matchesmask = createMask(sift_matchesmask, sift_match)
akaze_matchesmask = createMask(akaze_matchesmask, akaze_match)

sift_result = cv.drawMatchesKnn(
    img_obj,  sift_kp_obj,
    img_scn, sift_kp_scn,
    sift_match, None,
    matchColor=[255,0,0], singlePointColor = [0,255,0],
    matchesMask = sift_matchesmask
)

akaze_result = cv.drawMatchesKnn(
    img_obj,  akaze_kp_obj,
    img_scn, akaze_kp_scn,
    akaze_match, None,
    matchColor=[255,0,0], singlePointColor = [0,255,0],
    matchesMask = akaze_matchesmask
)

orb_result = cv.drawMatches(
    img_obj, orb_kp_obj,
    img_scn, orb_kp_scn,
    #ambil 20 index pertama
    orb_match[:20], None,
    matchColor = [255,0,0], singlePointColor = [0,255,0],
    flags = 2
)

matching_labels = ['sift', 'akaze', 'orb']
matching_images = [sift_result, akaze_result, orb_result]

plt.figure(figsize=(12,12))
for i, (lbl, img) in enumerate(zip(matching_labels, matching_images)):
    plt.subplot(2,2,i+1)
    plt.imshow(img,cmap='gray')
    plt.title(lbl)
plt.show()
